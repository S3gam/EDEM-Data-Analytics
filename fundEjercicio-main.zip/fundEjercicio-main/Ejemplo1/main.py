
while True:
    # Print current time and sleep 1 minute
    print("")
